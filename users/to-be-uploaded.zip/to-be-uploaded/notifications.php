<?php require('auth.php'); $title ='Notifications'; ?>

    <?php include('mgr_sidebar.php'); ?>
    <?php
		require('../db.php');
		$estate_code = $_SESSION['estate'];
		  if (isset($_POST['send_broadcast'])){
			$subject = $_REQUEST['subject'];
			$message = $_REQUEST['message'];	
			/*if( ! ini_get('date.timezone') ){
			  date_default_timezone_set('Africa/Lagos');
			}*/
			$trn_date = date("Y-m-d H:i:s");
			$query = "INSERT into `broadcast` (estate,subject, message, send_date) VALUES ('$estate_code','$subject', '$message', '$trn_date')";
			$result = mysqli_query($con,$query);
			if($result){
			  echo "<script>alert('Broadcast sent.');</script>";
			  echo "<script type='text/javascript'>window.top.location='notifications.php';</script>"; exit;
			}
			else{
			  echo "<script>alert('Broadcast was not sent.');</script>";
			  echo "<script type='text/javascript'>window.top.location='notifications.php';</script>"; exit;
			}
		  }
		  elseif (isset($_POST['send_msg'])){
			$subject = $_REQUEST['subject'];
			$message = $_REQUEST['message'];	
			$flat = $_REQUEST['flat'];
			if( ! ini_get('date.timezone') ){
			  date_default_timezone_set('Africa/Lagos');
			}
			$trn_date = date("Y-m-d H:i:s");
			$query = "INSERT into `messages` (sender,receiver,subject, message, date_received) VALUES ('$estate_code','$flat','$subject', '$message', '$trn_date')";
			$result = mysqli_query($con,$query);
			if($result){
			  echo "<script>alert('Message sent.');</script>";
			  echo "<script type='text/javascript'>window.top.location='notifications.php';</script>"; exit;
			}
			else{
			  echo "<script>alert('Message was not sent.');</script>";
			  echo "<script type='text/javascript'>window.top.location='notifications.php';</script>"; exit;
			}
		  }
		  else{
		?>
                    <div class="row">
						<div class="col-lg-12">
						  <div class="card m-b-30">
                            <div class="card-body">
							  <h4 class="mt-0 header-title">Messages</h4>
							  <span style="float: right"><a data-toggle="modal" data-target="#chatmodal" data-original-title="Contact Resident"><i class="fa fa-comment text-success m-r-10 m-b-10"> <b>Contact Resident</b></i></a></span>
							  <div class="table-responsive b-0" data-pattern="priority-columns">
							    <?php include ('../db.php');
									$sql = "SELECT * FROM messages join flats on messages.sender=flats.email where receiver='".$estate_code."' ";
									$result = $con->query($sql);
									if ($result->num_rows > 0) { ?>
									<table id="tech-companies-1" class="table  table-striped">
                                      <thead>
                                        <tr class="titles">
                                          <th>Subject</th><th>Message</th><th>Sender</th>
                                          <th>Date Sent</th> 
                                        </tr>
                                      </thead>
                                      <tbody><?php while($row = $result->fetch_assoc()) { ?>
										<tr>
										  <td><?php echo $row['subject']; ?></td>
										  <td><?php echo $row['message']; ?></td>
										  <td><?php $sender="Flat ".$row['flat_no']."- Block ".$row['block_no']; echo $sender;//$row['sender']; ?></td>
										  <td><?php echo $row['date_received']; ?></td>
										</tr>
										<?php }
										  } else {echo "No messages yet.";} $con->close();
									    ?>
                                       </tbody>
                                    </table>
							  </div>
							</div>
                          </div>
						</div>
						<div class="col-lg-12">
						  <div class="card m-b-30">
                            <div class="card-body">
							  <h4 class="mt-0 header-title">Broadcasts</h4>
							  <span style="float: right"><a data-toggle="modal" data-target="#broadcastmodal" data-original-title="Add Fikxer"><i class="fa fa-bullhorn text-danger m-r-10 m-b-10"> <b>Send Broadcast</b></i></a></span>
							  <div class="table-responsive b-0" data-pattern="priority-columns">
							    <?php include ('../db.php');
									$sql = "SELECT * FROM broadcast where estate='".$estate_code."'";
									$result = $con->query($sql);
									if ($result->num_rows > 0) { ?>
									<table id="tech-companies-1" class="table  table-striped">
                                      <thead>
                                        <tr class="titles">
                                          <th>Subject</th><th>Message</th>
                                          <th>Date Sent</th> 
                                        </tr>
                                      </thead>
                                      <tbody><?php while($row = $result->fetch_assoc()) { ?>
										<tr>
										  <td><?php echo $row['subject']; ?></td>
										  <td><?php echo $row['message']; ?></td>
										  <td><?php echo $row['send_date']; ?></td>
										</tr>
										<?php }
										  } else {echo "No messages yet.";} $con->close();
									    ?>
                                       </tbody>
                                    </table>
							  </div>
							</div>
                          </div>
						</div>
						<!-- Modal -->
						<div class="modal fade" id="chatmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
							<div class="modal-dialog modal-dialog-centered" role="document">
							  <div class="modal-content">
								<div class="modal-header">
								  <h5 class="modal-title" id="exampleModalLongTitle">Contact Resident</h5>
								  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								  </button>
								</div>
								<div class="modal-body">
								  <form action="" method="POST"> 
									<div class="form-group">
									  <input type="text" name="subject" class="form-control" required placeholder="Subject"/>
									</div>
									<div class="form-group">
									  <textarea class="form-control form-control-sm" name="message" placeholder="Type message" style="height:50px"></textarea>
									</div>
									<div class="form-group">
									  <select class="form-control" required name="flat" >
									  <?php  include ('../db.php');
										$sql="select flat_no,block_no,email from flats where estate_code='".$_SESSION['estate']."'"; 
										$result = $con->query($sql);; 
										while($row = $result->fetch_assoc()) { 
										$flat = "Flat ".$row['flat_no'].", Block ".$row['block_no'];
									  ?>
									  <option value="<?php echo $row['email']; ?>"><?php echo $flat; ?></option><?php } ?>
									  </select>
									</div>
									<div class="form-group">
									  <button type="submit" name="send_msg" class="btn btn-outline-primary btn-block">Send Message</button>
									</div>
								  </form>   
								</div>
							  </div>
							</div>
						</div>
						<!-- Modal -->
						<div class="modal fade" id="broadcastmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
							<div class="modal-dialog modal-dialog-centered" role="document">
							  <div class="modal-content">
								<div class="modal-header">
								  <h5 class="modal-title" id="exampleModalLongTitle">Send Broadcast</h5>
								  <button type="button" class="close" data-dismiss="modal" aria-label="Close">
									<span aria-hidden="true">&times;</span>
								  </button>
								</div>
								<div class="modal-body">
								   <form action="" method="POST"> 
									<div class="form-group">
									  <input type="text" name="subject" class="form-control" required placeholder="Subject"/>
									</div>
									<div class="form-group">
									  <textarea class="form-control form-control-sm" name="message" placeholder="Type message" style="height:50px"></textarea>
									</div>
									<div class="form-group">
									  <button type="submit" name="send_broadcast" class="btn btn-outline-primary btn-block">Send Broadcast</button>
									</div>
								  </form>	
								</div>
							  </div>
							</div>
						</div>
						<!--<div class="col-lg-12">
						  <div class="card m-b-30">
                            <div class="card-body">
							  <h4 class="mt-0 header-title">Send Broadcast</h4>
                              <form action="" method="POST"> 
								<div class="form-group">
                                  <input type="text" name="subject" class="form-control" required placeholder="Subject"/>
                                </div>
								<div class="form-group">
                                  <textarea class="form-control form-control-sm" name="message" placeholder="Type message" style="height:50px"></textarea>
                                </div>
								<div class="form-group">
                                  <button type="submit" name="send_broadcast" class="btn btn-outline-primary btn-block">Send Broadcast</button>
                                </div>
							  </form>	
							  <h4 class="mt-0 header-title">Contact Flat</h4>
                              <form action="" method="POST"> 
							    <div class="form-group">
                                  <input type="text" name="subject" class="form-control" required placeholder="Subject"/>
                                </div>
								<div class="form-group">
                                  <textarea class="form-control form-control-sm" name="message" placeholder="Type message" style="height:50px"></textarea>
                                </div>
								<div class="form-group">
								  <select class="form-control" required name="flat" >
								  <?php  include ('../db.php');
									$sql="select flat_no,block_no,email from flats where estate_code='".$_SESSION['estate']."'"; 
									$result = $con->query($sql);; 
									while($row = $result->fetch_assoc()) { 
									$flat = "Flat ".$row['flat_no'].", Block ".$row['block_no'];
								  ?>
								  <option value="<?php echo $row['email']; ?>"><?php echo $flat; ?></option><?php } ?>
								  </select>
								</div>
								<div class="form-group">
                                  <button type="submit" name="send_msg" class="btn btn-outline-primary btn-block">Send Message</button>
                                </div>
							  </form>
                            </div>
                          </div>
						</div>-->
                    </div>
                    <!-- end row -->
                  </div>
                  <!-- container -->
                </div>
                <!-- Page content Wrapper -->
            </div>
            <!-- content -->

		  <?php include('footer.php'); } ?>

</html>