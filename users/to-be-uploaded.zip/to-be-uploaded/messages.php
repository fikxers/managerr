<?php require('auth.php'); $title ='Contact Facility Manager'; ?>

    <?php include('flat_sidebar.php'); ?>
    <?php
		require('../db.php');
		$estate_code = $_SESSION['estate'];
		  if (isset($_POST['send_msg'])){
			$subject = $_REQUEST['subject'];
			$message = $_REQUEST['message'];
			if( ! ini_get('date.timezone') ){
			  date_default_timezone_set('Africa/Lagos');
			}
			$trn_date = date("Y-m-d H:i:s");
			$query = "INSERT into `messages` (sender,receiver,subject, message, date_received) VALUES ('".$_SESSION['email']."','$estate_code','$subject', '$message', '$trn_date')";
			$result = mysqli_query($con,$query);
			if($result){
			  echo "<script>alert('Message sent.');</script>";
			  echo "<script type='text/javascript'>window.top.location='messages.php';</script>"; exit;
			}
			else{
			  echo "<script>alert('Message was not sent.');</script>";
			  echo "<script type='text/javascript'>window.top.location='messages.php';</script>"; exit;
			}
		  }
		  else{
		?>
                    <div class="row">
						<div class="col-lg-12">
						  <div class="card m-b-30">
                            <div class="card-body">
							  <h4 class="mt-0 header-title">Messages from FM</h4>
							  <div class="table-responsive b-0" data-pattern="priority-columns">
							    <?php include ('../db.php');
									$sql = "SELECT * FROM messages where receiver='".$_SESSION['email']."' ";
									$result = $con->query($sql);
									if ($result->num_rows > 0) { ?>
									<table id="tech-companies-1" class="table  table-striped">
                                      <thead>
                                        <tr class="titles">
                                          <th>Subject</th><th>Message</th>
                                          <th>Date Sent</th> 
                                        </tr>
                                      </thead>
                                      <tbody><?php while($row = $result->fetch_assoc()) { ?>
										<tr>
										  <td><?php echo $row['subject']; ?></td>
										  <td><?php echo $row['message']; ?></td>
										  <td><?php echo $row['date_received']; ?></td>
										</tr>
										<?php }
										  } else {echo "No messages yet.";} $con->close();
									    ?>
                                       </tbody>
                                    </table>
							  </div>
							</div>
                          </div>
						</div>
						<div class="col-lg-12">
						  <div class="card m-b-30">
                            <div class="card-body">
							  <h4 class="mt-0 header-title">Contact FM</h4>
                              <form action="" method="POST"> 
								<div class="form-group">
                                  <input type="text" name="subject" class="form-control" required placeholder="Subject"/>
                                </div>
								<div class="form-group">
                                  <textarea class="form-control form-control-sm" name="message" placeholder="Type message" style="height:50px"></textarea>
                                </div>
								<div class="form-group">
                                  <button type="submit" name="send_msg" class="btn btn-outline-primary btn-block">Send Message</button>
                                </div>
							  </form>
                            </div>
                          </div>
						</div>
                    </div>
                    <!-- end row -->
                  </div>
                  <!-- container -->
                </div>
                <!-- Page content Wrapper -->
            </div>
            <!-- content -->

		  <?php include('footer.php'); } ?>

</html>