<?php include('auth.php'); $title ='Work Orders'; 
if($_SESSION['admin_type']=='admin'){include('admin_sidebar.php'); }
else if($_SESSION['admin_type']=='mgr'){include('mgr_sidebar.php');}
else if($_SESSION['admin_type']=='flat'){include('flat_sidebar.php');}	
require('../db.php');

if (isset($_POST['equipment'])){
  $equipment = stripslashes($_REQUEST['equipment']);
  $description = stripslashes($_REQUEST['description']); $service = stripslashes($_REQUEST['service']);
  $date = stripslashes($_REQUEST['date']); $completion_date = stripslashes($_REQUEST['cdate']);
  //$status = stripslashes($_REQUEST['status']);		  
  //b4 insert, check if exists
  if( ! ini_get('date.timezone') ){date_default_timezone_set('Africa/Lagos');}
  $trn_date = date("Y-m-d H:i:s");
  //$query = "INSERT into `repairs` (flat,estate, status, created_at, equipment, description,preferred_date) VALUES ('".$_SESSION['email']."', '".$_SESSION['estate']."', 'pending','$trn_date', '$equipment', '$description','$date')";
  $query = "INSERT into `orders` (flat,estate,order_name,order_status, created_at, service description,preferred_date, completion_date, order_type) VALUES ('".$_SESSION['email']."', '".$_SESSION['estate']."','$equipment', 'pending','$trn_date','$service', '$description','$date','$completion_date','repairs')";
  //$query = "INSERT into `orders` (flat,estate,order_name,order_status, created_at, description,preferred_date, order_type) VALUES ('".$_SESSION['email']."', '".$_SESSION['estate']."','$equipment', 'pending','$trn_date', '$description','$date','repairs')";
  $result = mysqli_query($con,$query);
  if($result){
	echo "<script>alert('Work Order sent.');</script>";
	echo "<script type='text/javascript'>window.top.location='repairs.php';</script>"; exit;
  }
  else{
    echo "<script>alert('Work Order not successful.');</script>";
    echo "<script type='text/javascript'>window.top.location='repairs.php';</script>"; exit;
  }
}
else{
//echo "<script>alert('Error');</script>";
?>
<div class="page-content-wrapper ">
 <div class="container-fluid">
  <div class="row">       
    <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-body">
        <h4 class="mt-0 header-title">Work Orders</h4>
        <div class="table-rep-plugin">
          <div class="table-responsive b-0" data-pattern="priority-columns">
          <?php include ('../db.php');
    			$sql = "SELECT * FROM orders where flat='".$_SESSION['email']."' and order_type = 'repairs'";
    			//$sql = "SELECT * FROM repairs where flat='".$_SESSION['email']."'";
    			if($_SESSION['admin_type']=='admin'){$sql = "SELECT * FROM orders where order_type = 'repairs'";}
    			$result = $con->query($sql);
    			if ($result->num_rows > 0) { ?>
   			  <table id="tech-companies-1" class="table  table-striped">
                <thead>
                  <tr class="titles"><th>Asset</th><th>Service</th><th>Description</th><th>Start Date</th><th>Completion Date</th><th>Status</th></tr>
                </thead>
                <tbody> <?php while($row = $result->fetch_assoc()) { ?>
				  <tr><td><?php echo $row['order_name']; ?></td><td><?php echo $row['service']; ?></td>
				  	<td><?php echo $row['description']; ?></td><td><?php echo $row['preferred_date']; ?></td>
					<td><?php echo $row['completion_date']; ?></td><td><?php echo $row['order_status']; ?></td></tr>
					<?php }
					  } else { echo "No ordered repair."; }
					  $con->close(); ?>                                                       
                </tbody>
              </table>
          </div>
		</div>
        </div>
      </div>
    </div> <!-- end col -->
	  <div class="col-lg-12">
      <div class="card m-b-30">
        <div class="card-body">
        <h4 class="mt-0 header-title">Work Order</h4>
        <!--<p class="text-muted m-b-30 font-14">Book for repair and/or maintenance.</p>-->
        <form class="" action="upload.php" method="POST" enctype="multipart/form-data">
    		  <div class="form-group">
				<div class="form-group">
				  <select class="form-control" name="service" >
					<option value="">Select Service</option>
					<option value="Pickup and deliver item from Gate">Pickup and deliver item from Gate</option>
					<option value="Purchase Gas">Purchase Gas</option><option value="School runs">School runs</option>
					<option value="Errands">Errands</option><option value="Others">Others</option>
				 </select>
				</div>
				<select class="form-control" name="equipment" >
      			  <option value="">Asset/Equipment</option>
      	          <?php include ('../db.php');
      				$sql="select name,location from equipments where flat='".$_SESSION['email']."'"; 
      				$result = $con->query($sql);; 
      				while($row = $result->fetch_assoc()) { ?>
      				  <option value="<?php echo $row['name']; ?>"><?php echo $row['name']."-".$row['location']; ?></option><?php } ?>
      			</select>
				<div class="form-group">
				  <label>Start Date</label>
                  <input type="date" name="date" class="form-control" required placeholder="Choose Date">
				  <!--<input type="datetime-local">-->
                </div>
				<div class="form-group">
				  <label>Expected Completion Date</label>
                  <input type="date" name="cdate" class="form-control" required placeholder="Choose Date">
                </div>
				<div class="form-group">
                  <input type="textarea" name="description" class="form-control" placeholder="Description e.g I want to move from Lekki to Ajah"/>
                </div>
      			
    		  </div>
              <div class="form-group">
				<input type="file" class="form-control" name="files[]" multiple >
			  </div>
          <div class="form-group">
            <div><button type="submit" name="submit" class="btn btn-primary waves-effect waves-light">Submit</button><button type="reset" class="btn btn-secondary waves-effect m-l-5">Cancel</button></div>
          </div>
        </form>
        </div>
      </div>
    </div> <!-- end col -->   
  </div><!-- container -->
 </div><!-- Page content Wrapper -->
</div><!-- content -->
<?php include('footer.php'); } ?>
</html>