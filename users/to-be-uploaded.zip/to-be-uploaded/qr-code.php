<?php
// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL); 
include('auth.php'); $title="Generate Visitor's Pass";
include('flat_sidebar.php');	
require('../db.php');
if (isset($_POST['code'])){ 
  $name = stripslashes($_REQUEST['test']);
  $regno = stripslashes($_REQUEST['regno']);
  $comp = stripslashes($_REQUEST['comp']);
  $arr_date = stripslashes($_REQUEST['arr_date']);
  $arr_time = stripslashes($_REQUEST['arr_time']);
  
  $_SESSION['arr_date'] = $arr_date;
  $_SESSION['arr_time'] = $arr_time;
  
  $permitted_chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	function generate_string($input, $strength = 16) {
	    $input_length = strlen($input);
	    $random_string = '';
	    for($i = 0; $i < $strength; $i++) {
	        $random_character = $input[mt_rand(0, $input_length - 1)];
	        $random_string .= $random_character;
	    }
	    return $random_string;
	}
   $final = generate_string($permitted_chars, 5);
   $query = "INSERT into `entrance_codes` (code,visitor,reg_no,comp,arr_date,arr_time) VALUES ('$final','$name','$regno',$comp,'$arr_date','$arr_time')";
   $result = mysqli_query($con,$query);
   if($result){
	$final = 'Code: '.$final;
    echo '<script type="text/javascript">alert("'.$final.'");</script>';
	if (isset($_POST['addqr'])) {
	  echo "<script type='text/javascript'>window.top.location='../qr-code/barcode-script.php?test=".$_REQUEST['test']."&regno=".$_REQUEST['regno']."&comp=".$_REQUEST['comp']."&val=".$_REQUEST['val']."&t=".date('d-m-y h:i:s')."&arr_date=".$_REQUEST['arr_date']."&arr_time=".$_REQUEST['arr_time']."';</script>"; 
	}
    echo "<script type='text/javascript'>window.top.location='qr-code.php';</script>"; exit;
   }else{
	//echo "<script>alert('Error generating code.');</script>";
	$error=mysqli_error($con);
	echo '<script type="text/javascript">alert("'.$error.'");</script>';
	echo "<script type='text/javascript'>window.top.location='qr-code.php';</script>"; exit;
   }
}
else if (isset($_POST['qrcode'])){ 
   //$link = '../qr-code/barcode-script.php?test=" .$_REQUEST['test']."&regno=" .$_REQUEST['reg_no']."&email=" .$row['email']."' data-toggle='tooltip' data-original-title='Update'>
   echo "<script type='text/javascript'>window.top.location='../qr-code/barcode-script.php?test=".$_REQUEST['test']."&regno=".$_REQUEST['regno']."&comp=".$_REQUEST['comp']."&val=".$_REQUEST['val']."&t=".date('d-m-y h:i:s')."&arr_date=".$_REQUEST['arr_date']."&arr_time=".$_REQUEST['arr_time']."';</script>"; 
   //window.location="../qr-code/barcode-script.php?test="+document.getElementById('test').value+"&regno="+document.getElementById('regno').value+"&comp="+document.getElementById('comp').value+"&val="+document.getElementById('val').value+"&t="+now+"&arr_date="+document.getElementById('arr_date').value+"&arr_time="+document.getElementById('arr_time').value;
}
?>
<div class="row">
  <div class="col-lg-12">
    <div class="card m-b-30">
      <div class="card-body">
      <h4 class="mt-0 header-title">Visitor's Pass</h4>
      <form action="" method="POST">
	   <div class="form-row">
		<div class="form-group col-lg-3">
		  <input type="text" name="test" id="test" class="form-control" placeholder="Guest Name" required />
		</div>
		<div class="form-group col-lg-3">
		  <input type="text" name="regno" id="regno" class="form-control" placeholder="Vehicle Reg No" />
		</div>
		<div class="form-group col-lg-3">
		  <input type="number" min="0" name="comp" id="comp" class="form-control" placeholder="No of companions" />
		</div>
		<div class="form-group col-lg-3">
		  <input type="number" min="0" name="val" id="val" class="form-control" placeholder="Validation Period (hours)" />
		</div>
		<div class="form-group col-lg-6">
		  <label for="arr_date">Arrival date</label><input type="date" name="arr_date" id="arr_date" class="form-control" />
		</div>
		<div class="form-group col-lg-6">
		  <label for="arr_time">Arrival time</label><input type="time" name="arr_time" id="arr_time" class="form-control" />
		</div>
		<div class="form-group col-lg-12">
		  <div class="form-check">
		   <input type="checkbox" class="form-check-input" name="addqr" id="exampleCheck1">
		   <label class="form-check-label" for="exampleCheck1">Include QR Code</label>
		  </div>
		</div>
		
		<!--<div class="form-group col-lg-6">
		  <a href="javascript:void(0);" class="btn btn-block btn-outline-success" onclick="ftest()">Generate QR</a>
		  <input type="submit" name="qrcode" value="Generate QR" class="btn btn-block btn-outline-success">
		</div>-->
		<div class="form-group col-lg-12">
		  <input type="submit" name="code" value="Generate Code" class="btn btn-block btn-outline-info">
		</div>
	   </div>
	  </form>
      </div>
    </div>
  </div> 
</div><!-- end row -->
</div><!-- container -->
</div><!-- Page content Wrapper -->
</div><!-- content -->
<?php include('footer.php'); ?>
<script type="text/javascript">
  function ftest(){
  	const now = new Date();
  	var curr_time = now.toLocaleTimeString();
	window.location="../qr-code/barcode-script.php?test="+document.getElementById('test').value+"&regno="+document.getElementById('regno').value+"&comp="+document.getElementById('comp').value+"&val="+document.getElementById('val').value+"&t="+now;
	//window.location="../qr-code/barcode-script.php?test="+document.getElementById('test').value+"&regno="+document.getElementById('regno').value+"&comp="+document.getElementById('comp').value+"&val="+document.getElementById('val').value+"&t="+now+"&arr_date="+document.getElementById('arr_date').value+"&arr_time="+document.getElementById('arr_time').value;
  }
</script>
</html>
